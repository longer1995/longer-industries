# BRANDON LONGER

**Houston, TX** · longerindustries@gmail.com · Longer Industries

---

## EXECUTIVE SUMMARY

Results-driven entrepreneur and operations executive with 8+ years of experience building and scaling businesses in defense, manufacturing, and industrial sectors. Proven track record of raising $3M+ in capital, generating $1.8M in annual revenue, and structuring complex international deals across multiple continents. Combines founder-level strategic thinking with hands-on operational expertise in manufacturing, sales, logistics, and compliance.

---

## PROFESSIONAL EXPERIENCE

### Vice President — Severe Service Valve Manufacturing Company
**Houston, TX · 2024 – 2026**

- Served as a senior executive overseeing operations at an industrial valve manufacturer specializing in severe service applications for oil & gas, petrochemical, and power generation sectors
- Drove business development and sales strategy for high-specification valve products in demanding industrial environments
- Managed cross-functional teams across engineering, manufacturing, and commercial operations
- Contributed to revenue growth and market expansion within the severe service valve segment

---

### Co-Founder — GCDL Defense (formerly NAO)
**2023 – Present**

- Co-founded a conventional ordnance company focused on manufacturing, assembly, and international sales
- Spearheaded fundraising efforts and capital strategy to launch and scale operations
- Built and managed international business development pipelines across **Eastern Europe, South Asia (India/Pakistan), and South America**
- Structured and negotiated complex international defense deals involving multi-party stakeholders, export compliance, and cross-border logistics
- Oversaw end-to-end operations: manufacturing, assembly, quality control, sales, and distribution
- Established relationships with international defense buyers, government entities, and supply chain partners

---

### Founder & CEO — American Munitions
**2019 – 2025**

- Founded and scaled an ammunition import and manufacturing company from zero to **$1.8M in annual revenue**
- Raised **$3M in growth capital** from private investors to fund operations, inventory, and manufacturing infrastructure
- Built and managed complete operational infrastructure: manufacturing lines, supply chain, warehousing, and distribution
- Directed all sales and business development efforts, growing a diversified customer base across commercial and institutional channels
- Maintained full regulatory compliance across federal, state, and ATF requirements for ammunition manufacturing and import
- Managed P&L, cash flow, vendor relationships, and a team of operations and production staff

---

### Business Development & Fundraising — Seated App
**Boston, MA · 2017 – 2019**

- Contributed to a **$12M seed round**, personally raising **$100K** in investor commitments as one of the company's earliest team members
- Started as an intern and was converted to a full-time role based on performance and fundraising results
- Supported investor relations, pitch preparation, and capital raise strategy for the restaurant technology startup
- Gained foundational experience in startup fundraising, investor communications, and high-growth business environments

---

## CORE COMPETENCIES

| | | |
|---|---|---|
| **Capital Raising & Investor Relations** | **International Business Development** | **Manufacturing Operations** |
| **Deal Structuring & Negotiation** | **Sales & Revenue Growth** | **Supply Chain & Logistics** |
| **Defense & Ordnance Industry** | **Regulatory Compliance (ATF, Export)** | **P&L Management** |
| **Industrial Equipment & Valves** | **Cross-Border Trade** | **Team Building & Leadership** |

---

## EDUCATION

**University Studies** — Business  
*Departed sophomore year to accept a full-time position after demonstrating exceptional performance during internship*

---

## ADDITIONAL

- **Industries:** Defense & Ordnance, Ammunition Manufacturing, Industrial Valves (Severe Service), Restaurant Technology
- **International Markets:** Eastern Europe, India, Pakistan, South America
- **Capital Raised:** $3M+ across ventures
- **Revenue Generated:** $1.8M annually (American Munitions)
